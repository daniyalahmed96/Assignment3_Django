from django.core.exceptions import ValidationError
from .models import UserProfile, User

def email_vailidator(email):
	pass