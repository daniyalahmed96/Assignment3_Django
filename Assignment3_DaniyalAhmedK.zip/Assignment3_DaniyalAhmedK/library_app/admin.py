from django.contrib import admin
from .models import *


admin.site.register(Author)
# admin.site.register(Publisher)
# admin.site.register(LendPeriods)
# admin.site.register(Book)
# admin.site.register(UserProfile)
# admin.site.register(QuotationFromBook)
